Para rodar

```bash
$ python3 topological_search.py
```

Para rodar

```bash
$ python3 transmissao_energia.py
```
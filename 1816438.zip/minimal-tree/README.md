Para rodar

```bash
$ python3 minimal_tree.py
```